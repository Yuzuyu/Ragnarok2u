<?php
if (!defined('FLUX_ROOT')) exit;

$title = Flux::message('TermsTitle');
?>