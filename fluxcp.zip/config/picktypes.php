<?php
return array(
	'T' => 'Traded',
	'V' => 'Vended',
	'P' => 'Player',
	'M' => 'Monster',
	'S' => 'NPC (Shop)',
	'N' => 'NPC (Script)',
	'D' => 'Stolen/Ganked',
	'C' => 'Consumed',
	'O' => 'Produced',
	'U' => 'MVP',
	'A' => 'Admin',
	'R' => 'Storage',
	'G' => 'Guild Storage',
	'E' => 'Mailed',
	'I' => 'Auctioned',
	'B' => 'Buy Store',
	'L' => 'Looted',
	'X' => 'Other'
);
?>