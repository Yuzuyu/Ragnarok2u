<?php
return array(
	19   => 'Bard',
	20   => 'Dancer',
	4020 => 'Clown',
	4021 => 'Gypsy',
	4042 => 'Baby Bard',
	4043 => 'Baby Dancer',
	4068 => 'Minstrel',
	4069 => 'Wanderer',
	4075 => 'Minstrel+',
	4076 => 'Wanderer+',
	4104 => 'Baby Minstrel',
	4105 => 'Baby Wanderer'
)
?>