<?php
return array(
	0 => 'Healing',
	//1 => 'Unknown',
	2 => 'Usable',
	3 => 'Etc',
	4 => 'Weapon',
	5 => 'Armor',
	6 => 'Card',
	7 => 'Pet Egg',
	8 => 'Pet Armor',
	//9 => 'Unknown2',
	10 => 'Ammo',
	11 => 'Delay Consume',
	//18 => 'Cash Shop Reward'
)
?>