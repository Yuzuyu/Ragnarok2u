<?php
return array(
	1     => 'Can Move',
	2     => 'Looter',
	4     => 'Aggressive',
	8     => 'Assist',
	16    => 'Cast Sensor Idle',
	32    => 'Boss',
	64    => 'Plant',
	128   => 'Can Attack',
	256   => 'Detector',
	512   => 'Cast Sensor Chase',
	1024  => 'Change Chase',
	2048  => 'Angry',
	4096  => 'Change Target Melee',
	8192  => 'Change Target Chase',
	16384 => 'Target Weak',
	32768 => 'Random Target' // Not implemented
)
?>
