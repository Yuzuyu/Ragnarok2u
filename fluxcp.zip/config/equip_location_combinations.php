<?php
return array(
	    0 => 'None',
	 4096 => 'Costume Low Headgear',
	 2048 => 'Costume Mid Headgear',
	 1024 => 'Costume Top Headgear',
	  256 => 'Upper Headgear',
	  512 => 'Middle Headgear',
	    1 => 'Lower Headgear',
	  769 => 'Upper/Mid/Lower Headgear',
	  768 => 'Upper/Mid Headgear',
	  //257 => 'Upper/Lower Headgear',
	  513 => 'Mid/Lower Headgear',
	   16 => 'Armor',
	    2 => 'Weapon',
	   32 => 'Shield',
	   34 => 'Two-Handed',
	   50 => 'Armor/Hands',
	    4 => 'Garment',
	   64 => 'Footgear',
	  136 => 'Accessories',
	32768 => 'Arrow'
)
?>