<?php
return array(
	 4096 => 'Costume Low Headgear',
	 2048 => 'Costume Mid Headgear',
	 1024 => 'Costume Top Headgear',
	  256 => 'Upper Headgear',
	  512 => 'Middle Headgear',
	    1 => 'Lower Headgear',
	   16 => 'Armor',
	    2 => 'Main Hand',
	   32 => 'Off Hand',
	    4 => 'Garment',
	   64 => 'Footgear',
	    8 => 'Accessory 1',
	  128 => 'Accessory 2',
	32768 => 'Arrow'
)
?>