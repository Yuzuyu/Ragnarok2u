<?php
return array(
	10   => 'Blacksmith',
	4011 => 'Whitesmith',
	4033 => 'Baby Blacksmith',
	4058 => 'Mechanic',
	4064 => 'Mechanic+',
	4100 => 'Baby Mechanic'
)
?>
