<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>CP Logs</h2>
<p>You may view the CP logs here.</p>
<p>Please select the log that you would like to view from the available menus.</p>