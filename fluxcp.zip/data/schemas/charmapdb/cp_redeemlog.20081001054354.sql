ALTER TABLE `cp_redeemlog`
	ADD `credits_before` INT( 10 ) NOT NULL ,
	ADD `credits_after` INT( 10 ) NOT NULL